package persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import domain.BoardVO;

@Repository
public class BoardDAOImpl implements BoardDAO {
	
	@Inject
	private SqlSession session;
	
	@Override
	public void create(BoardVO board) throws Exception {
		session.insert("board-mapper.create",board);
		
	}

	@Override
	public BoardVO read(Integer bno) throws Exception {
		return session.selectOne("board-mapper.read",bno);
	}

	@Override
	public void update(BoardVO board) throws Exception {
		session.update("board-mapper.update",board);
		
	}

	@Override
	public void delete(Integer bno) throws Exception {
		session.delete("board-mapper.delete",bno);
		
	}

	@Override
	public List<BoardVO> listAll() throws Exception {
		return session.selectList("board-mapper.listAll");
	}

	/*
	 * @Override public Integer getMaxBno() throws Exception { return
	 * session.selectOne("board-mapper.getMaxBno"); }
	 */
	

}
